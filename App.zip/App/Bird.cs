﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace FlappyBird
{
    class Bird
    {
        public int X, Y,Inaltime,Latime;
        int Viteza=0;
        int VitezaAripi=-10;
        int Gravitatia = 1; 
        public Bird(int X, int Y)
        {
            this.X = X;
            this.Y = Y;
            Inaltime = 30;
            Latime = 30;
        }
        public void Deseneaza(Graphics g)
        {
            g.DrawImage(FlappyBird.Properties.Resources.FlappyBird, X, Y, Inaltime, Latime);
        }
        public void Miscare()
        {
            Viteza = Viteza + Gravitatia;
            this.Y=this.Y+Viteza;
        }
        public void MiscareAripi()
        {
            Viteza=VitezaAripi;
            this.Y = this.Y+Viteza;
        }
        public bool LovitSol()
        {
            return (this.Y >= Sol.PozitieSol);

        }
        public bool LovitTurnuri(PerecheTurnuri pereche)
        {
            if(X+Latime>=pereche.turnSus.X && X<=pereche.turnSus.X+pereche.turnSus.Latime){
                if(Y<=pereche.turnSus.Inaltime) return true;
            }
            if (X + Latime >= pereche.turnJos.X && X <= pereche.turnJos.X + pereche.turnJos.Latime)
            {
                if (Y+Inaltime >= Sol.PozitieSol-pereche.turnJos.Inaltime) return true;
            }
            return false;
        }
    }
}
