﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace FlappyBird
{
    class PerecheTurnuri
    {
        public TurnJos turnJos;
        public TurnSus turnSus;
        public int PasajTrecere = 150;
        public bool Numarat= false;
        public PerecheTurnuri(int X)
        {
            Random rnd = new Random();
            int InaltimeTurnSus=TurnSus.InaltimeMinima+rnd.Next(Sol.PozitieSol-TurnJos.InaltimeMinima-PasajTrecere);
            int InaltimeTurnJos = Sol.PozitieSol - PasajTrecere-InaltimeTurnSus;
            turnSus = new TurnSus(X, InaltimeTurnSus);
            turnJos = new TurnJos(X, InaltimeTurnJos);
        }
        public void DeseneazaTurnuri(Graphics g)
        {
            turnJos.Deseneaza(g);
            turnSus.Deseneaza(g);
        }
        public void Miscare()
        {
            turnSus.Miscare();
            turnJos.Miscare();
        }
    }
}
