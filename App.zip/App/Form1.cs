﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FlappyBird
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Sol.PozitieSol = this.Height-50;
            bird = new Bird(this.Width / 2-50, this.Height / 2-150);
            lista=new List<PerecheTurnuri>();
        }
        Bird bird;
        List<PerecheTurnuri> lista;
        private void timer1_Tick(object sender, EventArgs e)
        {
            bird.Miscare();
            for (int i = 0; i < lista.Count;i++ )
            {
                lista[i].Miscare();
            }
            VerificaLovire();
            Numarare();
            this.pictureBox1.Refresh();
        }
        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            for (int i = 0; i < lista.Count; i++)
            {
                lista[i].DeseneazaTurnuri(e.Graphics);
            }
            bird.Deseneaza(e.Graphics);
            Sol.Deseneaza(e.Graphics,this.Width);
            Punctaj.DeseneazaPunctaj(e.Graphics);
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                bird.MiscareAripi();
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            PerecheTurnuri pereche = new PerecheTurnuri(this.Width);
            lista.Add(pereche);
            if (lista[0].turnSus.X + lista[0].turnSus.Latime < 0) lista.RemoveAt(0); 
        }
        private void Numarare()
        {
            for (int i = 0; i < lista.Count;i++ )
            {
                if (bird.X > lista[i].turnSus.X + lista[i].turnSus.Latime && lista[i].Numarat == false)
                {
                    Punctaj.Valoare++;
                    lista[i].Numarat = true;
                }
            }
        }
        private void VerificaLovire()
        {
            bool lovit = false;
            if (bird.LovitSol()) lovit = true;
            for (int i = 0; i < lista.Count;i++ )
            {
                if (bird.LovitTurnuri(lista[i])) lovit = true;
            }
            if (lovit) {
                Punctaj.ReinitializarePunctaj();
                lista.Clear();
                bird = new Bird(this.Width / 2 - 50, this.Height / 2 - 150);
            }
        }
    }
}
