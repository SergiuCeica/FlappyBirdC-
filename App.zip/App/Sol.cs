﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace FlappyBird
{
    static class Sol
    {
        static public int PozitieSol=700;
        public static void Deseneaza(Graphics g, int Latime)
        {
            g.DrawImage(FlappyBird.Properties.Resources.Iarba,0, PozitieSol-50,Latime,100);
        }
    }
}
